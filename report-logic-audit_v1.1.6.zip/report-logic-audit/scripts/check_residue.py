# -*- coding: utf-8 -*-
"""check_residue.py —— 跨报告模板残留关卡（v1.1.4 新增）

背景：迅捷兴（688655）报告复用了北芯生命（688712）的图脚本模板，
图 3 的数据区已改成 PCB，但左右子图标题/注释仍残留「IVUS」（北芯语境），
渲染出「标题与数据互相矛盾」的图，且此前三关全部漏过——
机械关只查 docx 文本，不查图脚本配置区与渲染产物的一致性。

本关扫 docx 全文（段落 + 表格 + 页眉页脚）中「上一份报告的标识词」，
并在 SKILL.md 流程层要求：克隆图脚本后、出图前，对脚本源文件跑同名检查。

用法：
  python check_residue.py <docx> --ban "北芯,688712,IVUS"
  --ban   逗号分隔的禁词列表（旧公司简称 / 旧代码 / 旧领域词 / 旧模板变量名）

输出：逐条命中明细 + 汇总行；有命中时退出码 1。
"""
import argparse
import sys

from docx import Document


def iter_text(doc):
    for p in doc.paragraphs:
        if p.text.strip():
            yield "正文", p.text
    for ti, t in enumerate(doc.tables, 1):
        for r in t.rows:
            for c in r.cells:
                if c.text.strip():
                    yield f"表{ti}", c.text
    for si, sec in enumerate(doc.sections, 1):
        for block, tag in ((sec.header, "页眉"), (sec.footer, "页脚")):
            for p in block.paragraphs:
                if p.text.strip():
                    yield f"页{tag}{si}", p.text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("docx")
    ap.add_argument("--ban", required=True,
                    help="逗号分隔禁词（上一份报告的公司简称/代码/领域词等）")
    args = ap.parse_args()
    bans = [w.strip() for w in args.ban.split(",") if w.strip()]
    if not bans:
        print("!! --ban 为空，无检查内容")
        sys.exit(2)

    doc = Document(args.docx)
    hits = []
    for where, text in iter_text(doc):
        for w in bans:
            if w in text:
                hits.append((where, w, text.strip()[:60]))

    for where, w, snippet in hits:
        print(f"[FIX] 残留 {w!r} @ {where}: {snippet}")
    n = len(hits)
    print(f"汇总: 残留命中={n} 禁词数={len(bans)} → {'PASS' if n == 0 else 'FAIL'}")
    sys.exit(1 if n else 0)


if __name__ == "__main__":
    main()
